import {html} from "../node_modules/lit-html/lit-html.js";

export const townView = (townName)=>html`<li>${townName}</li>`
