const section = document.getElementById('homePage');

function showHome(context) {
    context.showSection(section);
}

export {showHome}
